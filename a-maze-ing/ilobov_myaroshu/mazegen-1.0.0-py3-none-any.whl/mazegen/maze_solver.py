from .direction_constants import DIRECTION_DELTAS
from collections import deque
from .maze import Maze


class MazeSolver:
    """Solves a maze by finding the shortest path from entry to exit.

    Uses breadth-first search (BFS) to find the shortest path in the maze grid.
    """

    def __init__(self, maze: Maze) -> None:
        """Initialize MazeSolver with a maze.

        Args:
            maze: The maze to solve.
        """
        self.maze = maze

    def shortest_path(self) -> str:
        """Find the shortest path from maze entry to exit.

        Returns:
            str: Path as a string of directions (N/E/S/W).

        Raises:
            ValueError: If no valid path exists from entry to exit.
        """
        start_row, start_col = self.maze.entry
        end_row, end_col = self.maze.exit

        start = (start_row, start_col)
        end = (end_row, end_col)

        queue = deque([start])
        visited = {start}
        parent: dict[tuple[int, int], tuple[tuple[int, int], str]] = {}

        while queue:
            r, c = queue.popleft()
            if (r, c) == end:
                break

            cell = self.maze.grid[r][c]
            for d, (dr, dc) in DIRECTION_DELTAS.items():
                if cell.walls[d]:
                    continue  # стена закрыта

                nr, nc = r + dr, c + dc
                if not (0 <= nr < self.maze.height and 0 <= nc < self.maze.width):  # noqa: E501
                    continue
                if (nr, nc) in visited:
                    continue
                if getattr(self.maze.grid[nr][nc], "blocked", False):
                    continue

                visited.add((nr, nc))
                parent[(nr, nc)] = ((r, c), d)
                queue.append((nr, nc))

        if end not in visited:
            raise ValueError(
                f"No valid path from entry {self.maze.entry} to exit {self.maze.exit}. "  # noqa: E501
                "Maze may be unsolvable or entry/exit are blocked."
            )

        path: list[str] = []
        cur = end
        while cur != start:
            prev, d = parent[cur]
            path.append(d)
            cur = prev

        path.reverse()
        return "".join(path)
